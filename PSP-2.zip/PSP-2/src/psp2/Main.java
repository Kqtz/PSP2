package psp2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class Main {
    public static void main(String[] args) {
        // Mensaje informativo en la terminal al iniciar la aplicación
        System.out.println("El programa está cargando...");

        // Ejecutar la aplicación en el hilo de eventos de Swing
        SwingUtilities.invokeLater(() -> {
            try {
                new AplicacionMusica().iniciar(); // Crear y comenzar la aplicación
            } catch (Exception e) {
                // Mensaje de error en caso de fallo al iniciar.
                System.err.println("Error al iniciar la aplicación: " + e.getMessage());
            }
        });
    }
}

class AplicacionMusica {
    private JFrame ventana; // Ventana principal de la aplicación
    private JTable tablaArchivos; // Tabla para mostrar los archivos de música encontrados
    private DefaultTableModel modeloTabla; // Modelo de datos para gestionar la tabla
    private final List<File> listaMusica; // Lista que almacena los archivos de música encontrados
    private Player reproductorActual = null; // Reproductor de música en uso
    private Thread hiloReproduccion = null; // Hilo encargado de la reproducción de música
    private boolean detenerReproduccion = false; // Bandera para detener la reproducción

    public AplicacionMusica() {
        listaMusica = new ArrayList<>(); // Inicializar la lista de archivos de música
        try {
            inicializarComponentes(); // Configurar los componentes de la interfaz
            buscarMusicaEnSistema(); // Buscar archivos de música en el sistema
        } catch (Exception e) {
            // Mensaje de error si algo falla durante la inicialización
            System.err.println("Error al inicializar la aplicación: " + e.getMessage());
        }
    }

    // Método para iniciar la aplicación mostrando la ventana principal
    public void iniciar() {
        ventana.setVisible(true); // Hacer visible la ventana principal
    }

    // Configurar los componentes de la interfaz gráfica
    private void inicializarComponentes() {
        // Crear y configurar la ventana principal
        ventana = new JFrame("Psp-2 Álvaro Moreno Caballero");
        ventana.setSize(600, 400); // Establecer tamaño de la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar la aplicación al cerrar la ventana
        ventana.setLayout(new BorderLayout()); // Usar BorderLayout para organizar componentes
        ventana.getContentPane().setBackground(Color.LIGHT_GRAY); // Fondo gris claro

        // Crear el modelo de tabla con una columna para los nombres de los archivos
        modeloTabla = new DefaultTableModel(new Object[]{"Archivo de Música"}, 0);
        tablaArchivos = new JTable(modeloTabla); // Crear tabla con el modelo definido
        ventana.add(new JScrollPane(tablaArchivos), BorderLayout.CENTER); // Agregar la tabla al centro de la ventana

        // Crear un panel inferior con botones para reproducir y detener
        JPanel panelBotones = new JPanel();
        JButton btnReproducir = new JButton("\u25B6 Reproducir"); // Botón de reproducir
        JButton btnDetener = new JButton("\u25A0 Detener"); // Botón de detener
        panelBotones.add(btnReproducir); // Agregar botón de reproducir al panel
        panelBotones.add(btnDetener); // Agregar botón de detener al panel
        ventana.add(panelBotones, BorderLayout.SOUTH); // Agregar el panel inferior a la ventana

        // Acciones para los botones
        btnReproducir.addActionListener(e -> {
            int filaSeleccionada = tablaArchivos.getSelectedRow(); // Obtener la fila seleccionada
            if (filaSeleccionada != -1) { // Verificar que haya una fila seleccionada
                reproducirMusica(filaSeleccionada); // Reproducir el archivo seleccionado
            } else {
                // Mostrar mensaje de advertencia si no hay selección
                JOptionPane.showMessageDialog(ventana, "Seleccione un archivo para reproducir.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnDetener.addActionListener(e -> detenerMusica()); // Detener la música al presionar el botón

        ventana.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
    }

    // Buscar archivos de música en el sistema
    private void buscarMusicaEnSistema() {
        try {
            for (File unidad : File.listRoots()) { // Recorrer las unidades de disco disponibles
                buscarEnDirectorio(unidad, new String[]{"mp3", "wav"}); // Buscar archivos con extensión mp3 y wav
            }
            actualizarTabla(); // Actualizar la tabla con los archivos encontrados
        } catch (Exception e) {
            // Mensaje de error si ocurre algo durante la búsqueda
            System.err.println("Error al buscar música en el sistema: " + e.getMessage());
        }
    }

    // Buscar archivos en un directorio de forma recursiva
    private void buscarEnDirectorio(File directorio, String[] extensiones) {
        if (directorio != null && directorio.isDirectory()) { // Verificar si es un directorio válido
            File[] archivos = directorio.listFiles(); // Obtener archivos en el directorio
            if (archivos != null) {
                for (File archivo : archivos) { // Recorrer los archivos encontrados
                    if (archivo.isDirectory()) { // Si es un subdirectorio, buscar recursivamente
                        buscarEnDirectorio(archivo, extensiones);
                    } else {
                        // Verificar si el archivo tiene una de las extensiones deseadas
                        for (String extension : extensiones) {
                            if (archivo.getName().toLowerCase().endsWith(extension)) {
                                listaMusica.add(archivo); // Agregar el archivo a la lista
                                break; // Detener la búsqueda de extensiones
                            }
                        }
                    }
                }
            }
        }
    }

    // Actualizar la tabla con los archivos encontrados
    private void actualizarTabla() {
        listaMusica.forEach(archivo -> modeloTabla.addRow(new Object[]{archivo.getName()})); // Agregar archivos a la tabla
    }

    // Reproducir el archivo de música seleccionado
    private void reproducirMusica(int indice) {
        File archivo = listaMusica.get(indice); // Obtener el archivo seleccionado
        detenerMusica(); // Detener cualquier reproducción en curso
        detenerReproduccion = false; // Reiniciar la bandera de detención

        // Crear un hilo para la reproducción
        hiloReproduccion = new Thread(() -> {
            try (FileInputStream fis = new FileInputStream(archivo)) { // Crear flujo de entrada para el archivo
                reproductorActual = new Player(fis); // Inicializar reproductor con el archivo
                while (!detenerReproduccion) { // Reproducir mientras no se detenga
                    reproductorActual.play(1); // Reproducir un frame de audio
                }
            } catch (JavaLayerException | java.io.IOException ex) {
                // Mostrar error en la terminal si ocurre un problema durante la reproducción
                System.err.println("Error al reproducir música: " + ex.getMessage());
            }
        });
        hiloReproduccion.start(); // Iniciar el hilo de reproducción
    }

    // Detener la reproducción de músicaaa
    private void detenerMusica() {
        detenerReproduccion = true; // Establecer la bandera para detener
        if (reproductorActual != null) { // Si hay un reproductor activo
            reproductorActual.close(); // Cerrar el reproductor
            reproductorActual = null;
        }
        if (hiloReproduccion != null) { // Si hay un hilo en ejecución
            hiloReproduccion.interrupt(); // Interrumpir el hilo
            hiloReproduccion = null;
        }
    }
}
